package tests

import org.scalatest._
import functions.Numbers

class TestNumbers extends FunSuite {
  test("") {
    println(Numbers.fib(4))
  }
}
